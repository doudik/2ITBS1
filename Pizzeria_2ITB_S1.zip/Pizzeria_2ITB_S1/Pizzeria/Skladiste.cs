﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizzeria
{
    internal class Skladiste
    {
        //Ingredience
        // Koření
        //Šunka
        //Těsto
        //Sýr
        //    Eidam
        //    Gouda
        //    Parmazán
        //    Plesnivý sýr
        //Protlak
        //Smetana
        List<string> Sklads = new List<string> { "koreni", "sunka", "eidam", "gouda", "parmazan",
            "niva", "protlak", "smetana", "mouka", "voda", "drozdi", "sul"};
        public static List<Ingredience> dostupneIngredience = new List<Ingredience>();
        public Skladiste() {
            VygenerujPotraviny();
        }

        void VygenerujPotraviny() {
            //TODO vytvořit objekt Ingredience
            Random rnd = new Random();
            for (int i = 0; i < Sklads.Count; i++)
            {
                dostupneIngredience.Add(new Ingredience(Sklads[i], rnd.Next(500, 5000)));
            }
        }
        public void VypisPotraviny() {
            foreach (var item in dostupneIngredience) {
                Console.WriteLine("{0} - {1} g/ml \n", item.nazev, item.mnozstvi);
            }

        }
    }
}
