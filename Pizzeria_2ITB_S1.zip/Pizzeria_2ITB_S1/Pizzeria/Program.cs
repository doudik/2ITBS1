﻿using Pizzeria;

class Program
{
    static void Main(string[] args)
    {
        Skladiste skladiste = new Skladiste();
        skladiste.VypisPotraviny();
    }
}