﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizzeria
{
    internal class Ingredience
    {
        public string nazev { get; }
        public int mnozstvi { get; set; }
        public DateTime vyrobni_trvanlivost { get; }
        public DateTime konec_trvanlivosti { get; }
        
        public Ingredience(string nazev, int mnozstvi) {
            this.nazev = nazev;
            this.mnozstvi = mnozstvi;
            konec_trvanlivosti = vyrobni_trvanlivost.AddDays(7);    
        }

    }
}
