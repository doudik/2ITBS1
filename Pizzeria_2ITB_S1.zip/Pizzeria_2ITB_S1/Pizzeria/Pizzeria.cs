﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizzeria
{
    internal class Pizzeria
    {
        int mistVpeci = 2;
        bool pec = false; //false - prázdná | true - plná
        public int testo { get; private set; } = 0;

        //ingredience na těsto
        int needMouka = 250;
        int needSul = 5;
        int needVoda = 400;
        int needDrozdi = 45;


        public Pizzeria() {

        }
        int VratIndex(string ingredience) {
            for (int i = 0; i < Skladiste.dostupneIngredience.Count; i++)
            {
                if (Skladiste.dostupneIngredience[i].nazev == ingredience) {
                    return i;
                }
            }
            return -1;
        }
        void VyrobTesto() {
            //mouka, sul, voda, drozdi
            if (Skladiste.dostupneIngredience[VratIndex("mouka")].mnozstvi > needMouka &&
                Skladiste.dostupneIngredience[VratIndex("sul")].mnozstvi > needSul &&
                Skladiste.dostupneIngredience[VratIndex("voda")].mnozstvi > needVoda &&
                Skladiste.dostupneIngredience[VratIndex("drozdi")].mnozstvi > needDrozdi
                )
            {
                Skladiste.dostupneIngredience[VratIndex("mouka")].mnozstvi -= needMouka;
                Skladiste.dostupneIngredience[VratIndex("sul")].mnozstvi -= needSul;
                Skladiste.dostupneIngredience[VratIndex("voda")].mnozstvi -= needVoda;
                Skladiste.dostupneIngredience[VratIndex("drozdi")].mnozstvi -= needDrozdi;

                Console.WriteLine("Vyrobil si těsto");
                testo++;
            }
            else {
                Console.WriteLine("Nemáš dostatek surovin!");
            }
        }
        //TODO void VlozDoPece(Pizza pizza) { 
            //TODO pizzu do pece    
        }
        //TODO void VyndejZPece() { 
           //TODO vyndej pizzu z pece
        }



